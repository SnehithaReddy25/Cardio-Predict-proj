import streamlit as st
import numpy as np
import pandas as pd
import base64
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.feature_selection import RFE
from sklearn.model_selection import StratifiedKFold, cross_val_score
from imblearn.over_sampling import SMOTE
from streamlit_option_menu import option_menu

# ─── 1) PAGE SETUP ──────────────────────────────────────────────────────────────
st.set_page_config(page_title="Cardio Predict", layout="wide", initial_sidebar_state="collapsed")
st.markdown("""
    <style>
      #MainMenu, footer, header {visibility: hidden;}
      .stApp { background-color: #000000; color: #fafafa; }
      .card { background-color: #121212; border-radius: 12px; padding: 1.5rem; 
              box-shadow: 0 4px 12px rgba(255,255,255,0.05); }
      .stTextInput label, .stSelectbox label { font-size: 1.2rem; color: #ff5370; font-weight: bold; }
      .stButton>button { background-color: #ff5370; color: white; border-radius: 8px; }
      .stButton>button:hover { background-color: #e84560; }
    </style>
""", unsafe_allow_html=True)

st.markdown("""
<div style="text-align:center; margin-bottom:2rem;">
  <h1 style="color:#ff5370; font-size:3rem; margin:0;">❤ Cardio Predict</h1>
  <p style="color:#94a3b8; font-size:1.1rem; margin:0.2rem 0;">
    Advanced heart disease prediction using machine learning
  </p>
</div>
""", unsafe_allow_html=True)

# ─── 2) ECG VIDEO EMBED ─────────────────────────────────────────────────────────
def autoplay_video(video_path):
    with open(video_path, "rb") as f:
        base64_video = base64.b64encode(f.read()).decode()
    video_html = f"""
    <video autoplay muted loop playsinline style="width: 100%; border-radius: 12px; margin-bottom:1rem;">
        <source src="data:video/mp4;base64,{base64_video}" type="video/mp4">
    </video>
    """
    st.markdown(video_html, unsafe_allow_html=True)

# ✅ Replace with your video path
autoplay_video("C:/Users/bharg/Videos/anotherbalck.mp4")

# ─── 3) NAVIGATION ──────────────────────────────────────────────────────────────
if "page" not in st.session_state:
    st.session_state.page = "Predict"

selected = option_menu(
    menu_title=None,
    options=["Predict", "Result", "Learn"],
    icons=["heart", "bar-chart", "book"],
    default_index=["Predict", "Result", "Learn"].index(st.session_state.page),
    orientation="horizontal",
    styles={
        "container": {"padding": "0!important", "background-color": "#121212"},
        "nav-link-selected": {"background-color": "#ff5370", "color": "white"},
        "nav-link": {"font-size": "1.1rem", "margin": "0 0.5rem", "color": "#cbd5e1"},
    }
)
st.session_state.page = selected

# ─── 4) DATA LOAD ──────────────────────────────────────────────────────────────
@st.cache_data
def load_data():
    df = pd.read_csv("new heart.csv")
    X = df.drop(columns='target')
    Y = df['target']
    rfe = RFE(LogisticRegression(max_iter=1000, class_weight='balanced'), n_features_to_select=10)
    X_rfe = rfe.fit_transform(X, Y)
    pca = PCA(n_components=10)
    X_pca = pca.fit_transform(X_rfe)
    X_res, Y_res = SMOTE(random_state=23).fit_resample(X_pca, Y)
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X_res)
    return rfe, pca, scaler, X_scaled, Y_res

rfe, pca, scaler, X_proc, Y_proc = load_data()

# ─── 5) MODEL TRAINING ─────────────────────────────────────────────────────────
@st.cache_resource
def train_model(X, Y):
    models = {
        'LR': LogisticRegression(max_iter=1000, class_weight='balanced'),
        'RF': RandomForestClassifier(n_estimators=100, random_state=23, class_weight='balanced'),
        'SVM': SVC(probability=True, random_state=23, class_weight='balanced'),
        'KNN': KNeighborsClassifier(n_neighbors=5),
        'ADA': AdaBoostClassifier(n_estimators=100, random_state=23),
        'XGB': XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=23,
                             scale_pos_weight=Y.value_counts()[0] / Y.value_counts()[1])
    }
    best_model, best_score = None, -1
    kf = StratifiedKFold(n_splits=5, shuffle=True, random_state=23)
    for m in models.values():
        score = cross_val_score(m, X, Y, cv=kf, scoring='accuracy').mean()
        if score > best_score:
            best_model, best_score = m, score
    best_model.fit(X, Y)
    return best_model, best_score

model, accuracy = train_model(X_proc, Y_proc)
st.session_state.accuracy = accuracy

# ─── 6) PREDICT PAGE ───────────────────────────────────────────────────────────
if st.session_state.page == "Predict":
    st.markdown('<div class="card">', unsafe_allow_html=True)
    st.subheader("Patient Health Information")
    with st.form("predict_form"):
        c1, c2 = st.columns(2)
        with c1:
            age_in = st.text_input("Age","50")
            sex = st.selectbox("Sex", [0, 1], format_func=lambda x: "Female" if x == 0 else "Male")
            cp = st.selectbox("Chest Pain Type(0-Typical Angina,1-Atypical Angina,2-Non-Anginal Pain,3-Asymptomatic)", [0, 1, 2, 3])
            trestbps_in = st.text_input("Resting Blood Pressure","120")
            chol_in = st.text_input("Cholesterol (mg/dl)","150")
            fbs = st.selectbox("Fasting Blood Sugar(0-if <=120mg/dl,1-if >120mg/dl)", [0, 1], format_func=lambda x: "Yes" if x else "No")
            restecg = st.selectbox("ECG Results(0-Normal,1-ST-T Wave Abnormality,2-Probable) ", [0, 1, 2])
        with c2:
            thalach_in = st.text_input("Max Heart Rate","150")
            exang = st.selectbox("Exercise Induced Angina(0-No,1-Yes)", [0, 1], format_func=lambda x: "Yes" if x else "No")
            oldpeak_in = st.text_input("ST Depression","1")
            slope = st.selectbox("Slope of ST Segment(0-UnSloping,1-Flat,2-Down Sloping)", [0, 1, 2])
            ca = st.selectbox("Major Vessels (0–3)", [0, 1, 2, 3])
            thal = st.selectbox("Thalassemia(0-Normal,1-Fixed Defect,2-Reversible Defect,3-Temporary Issue)", [0, 1, 2, 3])

        submit = st.form_submit_button("Predict Heart Disease Risk")

    if submit:
        try:
            age = int(age_in)
            trestbps = int(trestbps_in)
            chol = int(chol_in)
            thalach = int(thalach_in)
            oldpeak = float(oldpeak_in)
        except ValueError:
            st.error("Please enter valid numbers in all numeric fields.")
        else:
            arr = np.array([[age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]])
            x_rfe = rfe.transform(arr)
            x_pca = pca.transform(x_rfe)
            x_sc = scaler.transform(x_pca)
            pred = model.predict(x_sc)[0]
            conf = model.predict_proba(x_sc)[0][pred]
            st.session_state.prediction = pred
            st.session_state.confidence = conf
            st.session_state.page = "Result"
            st.rerun()
    st.markdown('</div>', unsafe_allow_html=True)

# ─── 7) RESULT PAGE ────────────────────────────────────────────────────────────
if st.session_state.page == "Result":
    pred = st.session_state.get('prediction', None)
    conf = st.session_state.get('confidence', None)

    if pred is not None:
        is_healthy = pred == 0
        title = "Prediction Result"
        result_title = "Healthy Heart" if is_healthy else "⚠ Heart Disease Detected"
        result_msg = (
            "Your heart health parameters are within normal range. Keep up the healthy lifestyle! 💖" if is_healthy else
            "Risk of heart disease detected. Please consult a doctor for medical advice. 🩺"
        )
        color = "#00c851" if is_healthy else "#ff4444"

        st.markdown(f"""
        <div style="background-color: #121212; padding: 2rem; border-radius: 12px; border-left: 8px solid {color}; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">
            <h2 style="color: {color}; text-align: center;">{title}</h2>
            <h3 style="text-align: center; color: white;">{result_title}</h3>
            <p style="text-align: center; color: #cbd5e1;">{result_msg}</p>
            <div style="margin-top: 2rem;">
                <p style="color: #94a3b8;">Confidence Level</p>
                <div style="background-color: #334155; border-radius: 8px; height: 20px; overflow: hidden;">
                    <div style="width: {conf * 100:.0f}%; background-color: {color}; height: 100%;"></div>
                </div>
                <p style="color: white; text-align: right;">{conf * 100:.0f}%</p>
            </div>
            <p style="color: #94a3b8; font-size: 0.9rem; text-align:center;">
                Model Accuracy: {st.session_state.accuracy * 100:.2f}%
            </p>
            <p style="font-size: 0.9rem; color: #64748b; margin-top: 1rem; text-align:center;">
                (Note: This is a machine learning-based prediction, not a clinical diagnosis.)
            </p>
        </div>
        """, unsafe_allow_html=True)
# ─── 8) LEARN PAGE ─────────────────────────────────────────────────────────────
if st.session_state.page == "Learn":
    st.markdown("""
    <div class="card">
        <h2 style="color:#ff5370; font-size:3rem; text-align:center;">📚 Learn About Heart Disease</h2>
        <p style="text-align:center; color:#cbd5e1; font-size:1.3rem;">Explore key information using the tabs below</p>
    </div>
    """, unsafe_allow_html=True)

    tabs = st.tabs(["RISK FACTORS", "SYMPTOMS", "PREVENTION", "MEDICAL TERMS"])

    with tabs[0]:
        st.markdown("""
        ## Risk Factors
        - High blood pressure (hypertension)
        - High cholesterol levels
        - Diabetes or insulin resistance
        - Smoking and tobacco use
        - Excessive alcohol consumption
        - Poor diet (high in saturated fats, trans fat, and cholesterol)
        - Physical inactivity
        - Obesity or being overweight
        - Family history of heart disease
        - Chronic stress or poor mental health
        - Chronic stress or poor mental health
        """)

        with tabs[1]:
            st.markdown("""
              ## Symptoms
              - Chest pain or discomfort (angina)
              - Shortness of breath
              - Pain, numbness, or coldness in legs or arms
              - Dizziness or lightheadedness
              - Fatigue
              - Irregular heartbeat
              - Swelling in the legs, ankles, or feet
              """)

        with tabs[2]:
            st.markdown("""
              ## Prevention
              - Eat a heart-healthy diet (fruits, vegetables, whole grains)
              - Get regular physical activity
              - Maintain a healthy weight
              - Avoid tobacco and limit alcohol
              - Manage stress
              - Monitor blood pressure, cholesterol, and glucose levels
              - Follow prescribed medications
              """)
    with tabs[3]:
        st.markdown("""
        ## Medical Terms
        - Angina: Chest pain due to reduced blood flow to the heart muscle.
        - Arrhythmia: Irregular heartbeat (too fast, too slow, or irregular).
        - Atherosclerosis: Buildup of substances inside artery walls.
        - Cardiac Arrest: Sudden loss of heart function.
        - Coronary Artery Disease: Narrowing/blockage of heart arteries.
        - Electrocardiogram (ECG): Test recording electrical activity of the heart.
        - Myocardial Infarction: Heart attack.
        - Thalassemia: Inherited blood disorder affecting hemoglobin.
        """)